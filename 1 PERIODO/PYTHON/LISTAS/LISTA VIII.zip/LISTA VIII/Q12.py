i = 0

while i < 10:
    i += 1
    print(i)