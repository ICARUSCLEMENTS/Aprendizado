n1 = 1
n2 = 1
i = 0

while i < 10:
    print(n1)
    n3 = n1 + n2
    n1 = n2
    n2 = n3
    i += 1